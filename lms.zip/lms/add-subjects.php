<?php 
    include_once 'header.php';

?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                  
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add Subject</h6>
                        </div>
                        <div class="card-body">
                            <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Subject Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter subject name">
    
  </div>


  <div class="form-group">
    <label for="exampleInputEmail1">Course Name</label>
    <select name="department" id="cars" class="form-control">
  <option value="3D Computer Animation">3D Computer Animation</option>
  <option value="Academic Upgrading">Academic Upgrading</option>
  <option value="mercedes">Accommodation and Human Rights Management</option>
  <option value="audi">Administrative Business Management</option>
  <option value="3D Computer Animation">Animation</option>
  <option value="Academic Upgrading">Bachelor of Engineering - Power Systems Engineering</option>
  <option value="mercedes">Accommodation and Human Rights Management</option>
  <option value="audi">Agri-Business Management</option>
</select>
  </div>



  <div class="form-group">
    <label for="exampleInputPassword1">Subject Code</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter course code">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php 

    include_once 'footer.php';
  ?> 
