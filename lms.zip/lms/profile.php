<?php 
    include_once 'header.php';

?>

                <!-- Begin Page Content -->
<div class="container-fluid">
             <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">My Profile</h1>
        <div class="card shadow mb-4">           
            <div class="card-body">
                <form>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" readonly>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Password</label>
                        <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter password">
                    </div>



  <button type="submit" class="btn btn-primary">Submit</button>
</form>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php 

    include_once 'footer.php';
  ?> 
